import axios from "axios";
import { useState, useEffect } from "react";

function Editor({ chapter, refresh }) {
  const [content, setContent] = useState("");

  useEffect(() => {
    if (chapter) {
      setContent(chapter.content || "");
    }
  }, [chapter]);

  if (!chapter) return <div className="editor">选择章节</div>;

  const save = async () => {
    await axios.put(`http://localhost:5000/chapter/${chapter._id}`, {
      title: chapter.title, // ⭐锁定 title
      content,
    });

    refresh();
  };

  return (
    <div className="editor">
      {/* ❌ 不允许改标题 */}

      <h2>{chapter.title}</h2>

      <textarea value={content} onChange={(e) => setContent(e.target.value)} />

      <button onClick={save}>保存</button>
    </div>
  );
}

export default Editor;
