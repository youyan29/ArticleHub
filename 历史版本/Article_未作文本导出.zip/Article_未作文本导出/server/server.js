const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const Article = require("./models/Article");
const Chapter = require("./models/Chapter");
const Version = require("./models/Version");

const app = express();
app.use(cors());
app.use(express.json());

if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads");
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

mongoose
  .connect("mongodb://127.0.0.1:27017/articlehub")
  .then(() => {
    console.log("Mongo Connected");
  })
  .catch((err) => {
    console.log("Mongo Error:", err);
  });

/* ---------------- Article ---------------- */

// create
app.post("/article", async (req, res) => {
  const { title } = req.body;

  const exists = await Article.findOne({ title });

  if (exists) {
    return res.status(400).json({
      message: "Article title already exists",
    });
  }
  const article = await Article.create(req.body);
  res.json(article);
});

// get articles
app.get("/articles", async (req, res) => {
  const articles = await Article.find();

  const result = await Promise.all(
    articles.map(async (a) => {
      const count = await Chapter.countDocuments({
        articleId: a._id,
      });

      return {
        ...a.toObject(),

        chapterCount: count,
      };
    }),
  );

  res.json(result);
});

// update title
app.put("/article/:id", async (req, res) => {
  const { title, cover } = req.body;

  // ---------------- duplicate check ----------------
  const exists = await Article.findOne({ title });

  if (exists && exists._id.toString() !== req.params.id) {
    return res.status(400).json({
      message: "Article title already exists",
    });
  }

  // ---------------- safe update object ----------------
  const updateData = {};

  if (title) {
    updateData.title = title;
  }

  if (cover && typeof cover === "object" && cover.type && cover.value) {
    updateData.cover = {
      type: cover.type,
      value: cover.value,
    };
  }

  const article = await Article.findByIdAndUpdate(
    req.params.id,
    { $set: updateData },
    {
      returnDocument: "after",
    },
  );

  res.json(article);
});

// delete
app.delete("/article/:id", async (req, res) => {
  const chapters = await Chapter.find({
    articleId: req.params.id,
  });

  const ids = chapters.map((c) => c._id);

  await Version.deleteMany({
    chapterId: {
      $in: ids,
    },
  });

  await Chapter.deleteMany({
    articleId: req.params.id,
  });

  await Article.findByIdAndDelete(req.params.id);

  res.json({
    success: true,
  });
});

/* ---------------- Chapter ---------------- */

app.post("/chapter", async (req, res) => {
  const { articleId, title } = req.body;

  const exists = await Chapter.findOne({
    articleId,
    title,
  });

  if (exists) {
    return res.status(400).json({
      message: "Chapter title already exists in this article",
    });
  }

  const chapter = await Chapter.create(req.body);
  res.json(chapter);
});

app.get("/chapters/:articleId", async (req, res) => {
  const list = await Chapter.find({
    articleId: req.params.articleId,
  });

  res.json(list);
});

app.put("/chapter/:id", async (req, res) => {
  const title = req.body.title?.trim();
  const content = req.body.content;

  const current = await Chapter.findById(req.params.id);

  if (!current) {
    return res.status(404).json({
      message: "chapter not found",
    });
  }

  // ---------------- duplicate title check ----------------
  if (title && title !== current.title?.trim()) {
    const exists = await Chapter.findOne({
      articleId: current.articleId,
      title,
    });

    if (exists) {
      return res.status(400).json({
        message: "Chapter already exists",
      });
    }
  }

  // ---------------- detect content change ----------------
  const contentChanged = content !== current.content;

  // ---------------- update chapter ----------------
  const chapter = await Chapter.findByIdAndUpdate(
    req.params.id,
    {
      title,
      content,
    },
    { returnDocument: "after" }
  );

  // ---------------- ONLY create version if content changed ----------------
  if (contentChanged) {
    await Version.create({
      chapterId: chapter._id,
      content: chapter.content,
      message: req.body.message || "manual save",
      time: new Date(),
      isRestore: false,
    });
  }

  res.json(chapter);
});

app.delete("/chapter/:id", async (req, res) => {
  const chapterId = req.params.id;
  await Version.deleteMany({
    chapterId: chapterId,
  });
  await Chapter.findByIdAndDelete(req.params.id);
  res.json({
    success: true,
  });
});

/* ---------------- History ---------------- */

app.get("/history/:chapterId", async (req, res) => {
  try {
    const list = await Version.find({ chapterId: req.params.chapterId }).sort({
      time: -1,
    });

    res.json(list);
  } catch (err) {
    console.log("history error:", err);
    res.status(500).json({
      message: err.message,
    });
  }
});

app.post("/history/:id", async (req, res) => {
  const v = await Version.findByIdAndUpdate(
    req.params.id,
    { title: req.body.title },

    { returnDocument: "after" },
  );
  res.json(v);
});

app.put("/history/:id", async (req, res) => {
  const v = await Version.findById(req.params.id);
  let msg = req.body.message.trim();

  if (v.isRestore) {
    const oldMessage = v.message.replace("restore:", "").trim();
    msg = `${msg}（restore:${oldMessage}）`;
  }

  const updated = await Version.findByIdAndUpdate(
    req.params.id,
    { message: msg },
    { returnDocument: "after" },
  );
  res.json(updated);
});

/* ---------------- Restore ---------------- */

app.post("/restore/:versionId", async (req, res) => {
  const version = await Version.findById(req.params.versionId);
  if (version.isRestore) {
    return res.status(400).json({
      message: "restore version cannot restore again",
    });
  }

  await Chapter.findByIdAndUpdate(
    version.chapterId,

    {
      content: version.content,
      title: version.title,
    },
  );

  await Version.create({
    chapterId: version.chapterId,
    content: version.content,
    message: `restore: ${version.message}`,
    time: new Date(),
    isRestore: true,
  });

  res.json({
    success: true,
  });
});

app.use("/uploads", express.static("uploads"));

app.post("/upload", upload.single("image"), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        message: "no file uploaded",
      });
    }

    const url = `http://localhost:5000/uploads/${req.file.filename}`;

    res.json({ url });
  } catch (err) {
    console.error(err);

    res.status(500).json({
      message: "upload failed",
    });
  }
});

app.listen(5000, () => {
  console.log("server running on 5000");
});
