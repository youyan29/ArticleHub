import axios from "axios";
import { useState, useEffect } from "react";
import "../styles/editor.css";

function Editor({ chapter, refresh }) {
  const [content, setContent] = useState("");

  useEffect(() => {
    if (chapter) {
      setContent(chapter.content || "");
    }
  }, [chapter]);

  if (!chapter) return <div className="editor">选择章节</div>;

  const save = async () => {
    const msg = prompt("输入历史记录标题", "save");

    if (!msg?.trim()) return;

    await axios.put(`http://localhost:5000/chapter/${chapter._id}`, {
      title: chapter.title,
      content,
      message: msg.trim(),
    });

    refresh();
  };

  return (
    <div className="editor">
      <div className="editor-header">
        <h2>{chapter.title}</h2>
      </div>

      <div className="editor-body">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
      </div>

      <div className="editor-footer">
        <button onClick={save}>保存</button>
      </div>
    </div>
  );
}

export default Editor;
