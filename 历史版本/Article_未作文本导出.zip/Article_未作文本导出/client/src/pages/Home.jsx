import axios from "axios";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import "../styles/home.css";
import "../styles/theme.css";

function Home() {
  const nav = useNavigate();

  const [articles, setArticles] = useState([]);
  const [title, setTitle] = useState("");
  const [search, setSearch] = useState("");

  const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");

  // ---------------- theme ----------------
  useEffect(() => {
    document.body.className = theme;
    localStorage.setItem("theme", theme);
  }, [theme]);

  // ---------------- load ----------------
  const load = async () => {
    const res = await axios.get("http://localhost:5000/articles");
    setArticles(res.data);
  };

  useEffect(() => {
    load();
  }, []);

  // ---------------- create ----------------
  const create = async () => {
    if (!title.trim()) return;

    try {
      await axios.post("http://localhost:5000/article", {
        title: title.trim(),
        cover: {
          type: "emoji",
          value: "📘",
        },
      });

      setTitle("");
      load();
    } catch (err) {
      alert(err.response?.data?.message || "create failed");
    }
  };

  // ---------------- edit title + cover ----------------
  const editTitle = async (a) => {
    const t = prompt("edit title", a.title);
    if (!t) return;

    try {
      await axios.put(`http://localhost:5000/article/${a._id}`, {
        title: t,
      });

      load();
    } catch (err) {
      alert(err.response?.data?.message || "update failed");
    }
  };

  const uploadImage = async (file) => {
    const formData = new FormData();
    formData.append("image", file);

    const res = await axios.post("http://localhost:5000/upload", formData);

    return res.data.url;
  };

  const editCover = async (a) => {
    const file = document.createElement("input");
    file.type = "file";
    file.accept = "image/*";

    file.onchange = async (e) => {
      const img = e.target.files[0];

      if (!img) return;

      const url = await uploadImage(img);

      await axios.put(`http://localhost:5000/article/${a._id}`, {
        title: a.title,
        cover: {
          type: "image",
          value: url,
        },
      });

      load();
    };

    file.click();
  };

  // ---------------- delete ----------------
  const del = async (id) => {
    if (!window.confirm("Delete this article?")) return;

    await axios.delete(`http://localhost:5000/article/${id}`);
    load();
  };

  // ---------------- filter ----------------
  const filtered = articles.filter((a) =>
    a.title.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="container">
      {/* sidebar */}
      <div className="sidebar-nav">
        <h2>ArticleHub</h2>
        <div>🏠 Home</div>
      </div>

      {/* main */}
      <div className="main">
        {/* top bar */}
        <div className="top">
          <input
            placeholder="Search..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select value={theme} onChange={(e) => setTheme(e.target.value)}>
            <option value="light">☀ Light</option>
            <option value="dark">🌙 Dark</option>
            <option value="eye">🌿 Eye</option>
          </select>
        </div>

        {/* create */}
        <div className="create-row">
          <input
            placeholder="new article..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          <button onClick={create}>＋</button>
        </div>

        {/* cards */}
        <div className="grid">
          {filtered.map((a) => (
            <div
              key={a._id}
              className="card"
              onClick={() => nav(`/editor/${a._id}`)}
            >
              {/* top row */}
              <div className="card-top">
                <div
                  className="cover"
                  onClick={(e) => {
                    e.stopPropagation();
                    editCover(a);
                  }}
                >
                  {a.cover?.type === "image" ? (
                    <img src={a.cover.value} />
                  ) : (
                    a.cover?.value || "📘"
                  )}
                </div>

                <div className="actions">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      editTitle(a);
                    }}
                  >
                    ✎
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      del(a._id);
                    }}
                  >
                    🗑
                  </button>
                </div>
              </div>

              {/* title */}
              <h2>{a.title}</h2>

              {/* meta */}
              <div>chapters: {a.chapterCount || 0}</div>

              <div>
                updated:{" "}
                {a.updatedAt ? new Date(a.updatedAt).toLocaleString() : "-"}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Home;
