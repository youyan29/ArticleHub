const mongoose = require("mongoose");

const ArticleSchema = new mongoose.Schema(
  {
    title: String,

    cover: {
      type: {
        type: String,
        default: "emoji",
      },
      value: {
        type: String,
        default: "📘",
      },
    },
  },
  {
    timestamps: true,
  },
);

module.exports = mongoose.model("Article", ArticleSchema);
