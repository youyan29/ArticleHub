import Sidebar from "../components/Sidebar";
import Editor from "../components/Editor";
import History from "../components/History";
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import "../styles/layout.css";

function EditorPage() {
  const { articleId } = useParams();
  const nav = useNavigate();

  const [chapters, setChapters] = useState([]);
  const [currentChapter, setCurrentChapter] = useState(null);
  const [history, setHistory] = useState([]);
  const [showSidebar, setShowSidebar] = useState(true);
  const [showHistory, setShowHistory] = useState(true);
  const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");
  const [articleTitle, setArticleTitle] = useState("");

  // =========================
  // 读取文章信息
  // =========================
  useEffect(() => {
    const fetchArticle = async () => {
      try {
        const res = await axios.get(
          `http://localhost:5000/article/${articleId}`,
        );
        setArticleTitle(res.data.title || "未命名书籍");
      } catch (err) {
        console.log("获取文章失败", err);
      }
    };
    fetchArticle();
  }, [articleId]);

  // =========================
  // 初始化刷新章节
  // =========================
  const refreshAll = async (chapterId) => {
    const res = await axios.get(`http://localhost:5000/chapters/${articleId}`);
    const data = res.data;
    setChapters(data);

    if (data.length === 0) {
      setCurrentChapter(null);
      setHistory([]);
      return;
    }

    let target = data.find((c) => c._id === chapterId) || data[data.length - 1];
    setCurrentChapter(target);

    const h = await axios.get(`http://localhost:5000/history/${target._id}`);
    setHistory(h.data);
  };

  // =========================
  // 选择章节
  // =========================
  const selectChapter = async (chapter) => {
    setCurrentChapter(chapter);
    const res = await axios.get(`http://localhost:5000/history/${chapter._id}`);
    setHistory(res.data);
  };

  // =========================
  // 删除章节
  // =========================
  const deleteChapter = async (id) => {
    await axios.delete(`http://localhost:5000/chapter/${id}`);
    await refreshAll(currentChapter?._id === id ? null : currentChapter?._id);
  };

  // =========================
  // 刷新章节
  // =========================
  useEffect(() => {
    refreshAll();
  }, []);

  // =========================
  // 保存主题到 localStorage
  // =========================
  useEffect(() => {
    localStorage.setItem("theme", theme);
  }, [theme]);

  return (
    <div className={`layout ${theme}`}>
      {showSidebar && (
        <Sidebar
          articleId={articleId}
          chapters={chapters}
          onSelectChapter={selectChapter}
          refresh={() => refreshAll(currentChapter?._id)}
          onDeleteChapter={deleteChapter}
        />
      )}

      <div className="editor-area">
        <div className="topbar">
          <button onClick={() => nav("/")}>← Home</button>
          <button onClick={() => setShowSidebar(!showSidebar)}>☰</button>
          <button onClick={() => setShowHistory(!showHistory)}>🕘</button>
          <select value={theme} onChange={(e) => setTheme(e.target.value)}>
            <option value="light">☀ Light</option>
            <option value="dark">🌙 Dark</option>
            <option value="eye">🌿 Eye</option>
          </select>
        </div>

        <Editor
          chapter={currentChapter}
          refresh={() => refreshAll(currentChapter?._id)}
          articleTitle={articleTitle}
        />
      </div>

      {showHistory && (
        <History
          history={history}
          onRestore={() => refreshAll(currentChapter?._id)}
        />
      )}
    </div>
  );
}

export default EditorPage;
